import numpy as np

class Mat3D:
    def __init__(self, matrix):
        self.matrix = np.array(matrix)

    @staticmethod
    def identity():
        return Mat3D(np.identity(4))

    @staticmethod
    def translation(tx, ty, tz):
        return Mat3D([[1, 0, 0, tx],
                      [0, 1, 0, ty],
                      [0, 0, 1, tz],
                      [0, 0, 0, 1]])

    @staticmethod
    def scaling(sx, sy, sz):
        return Mat3D([[sx, 0, 0, 0],
                      [0, sy, 0, 0],
                      [0, 0, sz, 0],
                      [0, 0, 0, 1]])

    @staticmethod
    def rotation_x(theta):
        cos_theta = np.cos(theta)
        sin_theta = np.sin(theta)
        return Mat3D([[1, 0, 0, 0],
                      [0, cos_theta, -sin_theta, 0],
                      [0, sin_theta, cos_theta, 0],
                      [0, 0, 0, 1]])

    @staticmethod
    def rotation_y(theta):
        cos_theta = np.cos(theta)
        sin_theta = np.sin(theta)
        return Mat3D([[cos_theta, 0, sin_theta, 0],
                      [0, 1, 0, 0],
                      [-sin_theta, 0, cos_theta, 0],
                      [0, 0, 0, 1]])

    @staticmethod
    def rotation_z(theta):
        cos_theta = np.cos(theta)
        sin_theta = np.sin(theta)
        return Mat3D([[cos_theta, -sin_theta, 0, 0],
                      [sin_theta, cos_theta, 0, 0],
                      [0, 0, 1, 0],
                      [0, 0, 0, 1]])

    def __mul__(self, other):
        return Mat3D(np.dot(self.matrix, other.matrix))

    def transpose(self):
        return Mat3D(np.transpose(self.matrix))

    def transform_vector(self, vec):
        vec_ = np.append(vec, 1)
        transformed_vec = np.dot(self.matrix, vec_)
        return transformed_vec[:3]

# Example usage:
mat_identity = Mat3D.identity()
print("Identity Matrix:")
print(mat_identity.matrix)

mat_translation = Mat3D.translation(2, 3, 4)
print("Translation Matrix:")
print(mat_translation.matrix)

vec = np.array([1, 1, 1])
transformed_vec = mat_translation.transform_vector(vec)
print(f"Transformed Vector {vec} by Translation Matrix: {transformed_vec}")
