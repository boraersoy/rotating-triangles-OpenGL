import numpy as np

class Object:
    def __init__(self, vertices):
        self.vertices = vertices
        self.transformation_stack = []
        self.order = []

    def translate(self, tx, ty, tz):
        translation_matrix = np.array([[1, 0, 0, tx],
                                       [0, 1, 0, ty],
                                       [0, 0, 1, tz],
                                       [0, 0, 0, 1]])
        self.transformation_stack.append(translation_matrix)
        self.order.append("T")

    def rotate_x(self, angle):
        cos_theta = np.cos(angle)
        sin_theta = np.sin(angle)
        rotation_matrix_x = np.array([[1, 0, 0, 0],
                                      [0, cos_theta, -sin_theta, 0],
                                      [0, sin_theta, cos_theta, 0],
                                      [0, 0, 0, 1]])
        self.transformation_stack.append(rotation_matrix_x)
        self.order.append("RX")

    def rotate_y(self, angle):
        cos_theta = np.cos(angle)
        sin_theta = np.sin(angle)
        rotation_matrix_y = np.array([[cos_theta, 0, sin_theta, 0],
                                      [0, 1, 0, 0],
                                      [-sin_theta, 0, cos_theta, 0],
                                      [0, 0, 0, 1]])
        self.transformation_stack.append(rotation_matrix_y)
        self.order.append("RY")

    def rotate_z(self, angle):
        cos_theta = np.cos(angle)
        sin_theta = np.sin(angle)
        rotation_matrix_z = np.array([[cos_theta, -sin_theta, 0, 0],
                                      [sin_theta, cos_theta, 0, 0],
                                      [0, 0, 1, 0],
                                      [0, 0, 0, 1]])
        self.transformation_stack.append(rotation_matrix_z)
        self.order.append("RZ")

    def scale(self, sx, sy, sz):
        scale_matrix = np.array([[sx, 0, 0, 0],
                                 [0, sy, 0, 0],
                                 [0, 0, sz, 0],
                                 [0, 0, 0, 1]])
        self.transformation_stack.append(scale_matrix)
        self.order.append("S")

    def print_stack(self):
        for i in range(len(self.transformation_stack)):
            print(f"Transformation Order: {self.order[i]}")
            print(self.transformation_stack[i])

    def apply_RS(self):
        rs_matrix = np.eye(4)
        for transform in reversed(self.transformation_stack):
            rs_matrix = np.dot(transform, rs_matrix)
        return rs_matrix

    def apply_SRT(self):
        srt_matrix = np.eye(4)
        for transform in reversed(self.transformation_stack):
            srt_matrix = np.dot(transform, srt_matrix)
        return srt_matrix

    def apply_RTS(self):
        rts_matrix = np.eye(4)
        for transform in self.transformation_stack:
            rts_matrix = np.dot(rts_matrix, transform)
        return rts_matrix

# Example usage
obj = Object([(1, 1, 1), (2, 2, 2), (3, 3, 3)])  # Vertices as tuples of (x, y, z)
obj.translate(1, 2, 3)
obj.rotate_x(np.pi/4)
obj.rotate_y(np.pi/3)
obj.rotate_z(np.pi/6)
obj.scale(2, 2, 2)

print("RS Transformation:")
print(obj.apply_RS())
print("\nSRT Transformation:")
print(obj.apply_SRT())
print("\nRTS Transformation:")
print(obj.apply_RTS())
