class Vec3D:
    def __init__(self, x, y, z):
        self.x = x
        self.y = y
        self.z = z

    def __str__(self):
        return f"({self.x}, {self.y}, {self.z})"

    def __add__(self, other):
        return Vec3D(self.x + other.x, self.y + other.y, self.z + other.z)

    def __sub__(self, other):
        return Vec3D(self.x - other.x, self.y - other.y, self.z - other.z)

    def dot(self, other):
        return self.x * other.x + self.y * other.y + self.z * other.z

    def cross(self, other):
        return Vec3D(self.y * other.z - self.z * other.y,
                     self.z * other.x - self.x * other.z,
                     self.x * other.y - self.y * other.x)

    def scale(self, scalar):
        return Vec3D(self.x * scalar, self.y * scalar, self.z * scalar)

    def magnitude(self):
        return (self.x ** 2 + self.y ** 2 + self.z ** 2) ** 0.5

    def normalize(self):
        mag = self.magnitude()
        return Vec3D(self.x / mag, self.y / mag, self.z / mag)

# Example usage:
vec1 = Vec3D(1, 2, 3)
vec2 = Vec3D(4, 5, 6)

print("Vector 1:", vec1)
print("Vector 2:", vec2)
print("Vector 1 + Vector 2:", vec1 + vec2)
print("Vector 1 dot Vector 2:", vec1.dot(vec2))
print("Vector 1 cross Vector 2:", vec1.cross(vec2))
print("Vector 1 scaled by 2:", vec1.scale(2))
print("Magnitude of Vector 1:", vec1.magnitude())
print("Normalized Vector 1:", vec1.normalize())
